This code runs from the 'Runner' class. To run the code, simply set the value of the variable 'test' to the name of the problem instance that you want to test, and click run.

