package problem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.stream.IntStream;

/**
 * Class with memetic algorithm related methods 
 *
 */
public class Meme {
	FitnessEvaluator evaluator;
	int memeplexLength = 6;
	final int MR = 0;
	final int HC = 1;
	final int HCP = 2;
	final int CF = 3;
	final int RR = 4;
	final int RRP = 5;
	protected final int[] DOS = { 3, 5, 7};
	/**
	 * constructor that takes in the evaluator
	 * @param evaluator
	 */
	public Meme(FitnessEvaluator evaluator) {
		this.evaluator = evaluator;
	}

	/**
	 * mutates memeplexes depending on the specified innovationRate
	 * @param childmemeplexes
	 * @param innovationRate
	 * @return 2 child mutated memeplexes
	 */
	public int[][] mutateMemeplexes( int[][] childmemeplexes, double innovationRate) {
		for(int i = 0; i < childmemeplexes.length; i++) {
			int[] stream;
			if(Math.random() < innovationRate) {
				stream = IntStream.range(0, 3).toArray();
				stream = shuffleArray(stream);
				childmemeplexes[i][0] = stream[0];

			}
			if(Math.random() < innovationRate) {
				stream = IntStream.range(0, 4).toArray();
				stream = shuffleArray(stream);
				childmemeplexes[i][1] = stream[0];
			}
			if(Math.random() < innovationRate) {
				stream = IntStream.range(0, 3).toArray();
				stream = shuffleArray(stream);
				childmemeplexes[i][2] = stream[0];
			}

		}

		return childmemeplexes;
	}

	/**
	 * inheritance of entire memeplex from parent to child
	 * @param parents
	 * @param parentmemeplex1
	 * @param parentmemeplex2
	 * @return inherited memeplex
	 */
	public int[][] simpleInheritanceForMemeplex(int[][] parents, int[] parentmemeplex1, int[] parentmemeplex2) {

		int[][] childMemeplexes = new int[2][parentmemeplex1.length];
		double[] objectiveValues = new double[2];

		objectiveValues[0] = evaluator.evaluateSingleFitness(parents[0]);
		objectiveValues[1] = evaluator.evaluateSingleFitness(parents[1]);

		if(objectiveValues[0] == objectiveValues[0]) {
			int[] inherit = Math.random() < 0.5 ? parentmemeplex1 : parentmemeplex1;
			childMemeplexes[0] = inherit;
			childMemeplexes[1] = inherit;
		}else if(objectiveValues[0] > objectiveValues[1]) {
			childMemeplexes[0] = parentmemeplex1;
			childMemeplexes[1] = parentmemeplex1;
		}else if(objectiveValues[0] < objectiveValues[1]){
			childMemeplexes[0] = parentmemeplex2;
			childMemeplexes[1] = parentmemeplex2;
		}else {
			System.out.println("Error");
			return null;
		}

		return childMemeplexes;
	}

	/**
	 * initialises a population of memeplexes
	 * @param memeplexList
	 * @return a list of all the memeplexes for each individual
	 */
	public ArrayList<int[]>  initialiseMemeplex(ArrayList<int[]> memeplexList) {
		int[] memeplexTemp = new int[memeplexLength];
		memeplexTemp[MR]= (int) (Math.random()* 2) + 1;
		memeplexTemp[HC]= (int) (Math.random()* 3);
		memeplexTemp[HCP]= DOS[(int) (Math.random()* 2)];
//		memeplexTemp[CF]= (int) (Math.random()*2) + 2;
		memeplexTemp[CF]= 0;
		memeplexTemp[RR] = (int) (Math.random()* 2);
		memeplexTemp[RRP] = (int) (Math.random()* 3);
		memeplexList.add(memeplexTemp);
		return memeplexList;
	}

	/**
	 * shuffles array by swapping items in it
	 * @param array - integer array that needs shuffling
	 * @return integer array with elements in a different order
	 */
	public static int[] shuffleArray(int[] array) {
		for(int i = 0; i < array.length; i++) {
			int r = (int) Math.random()*array.length;
			int temp = array[i];
			array[r] = array[i];
			array[i] = temp;
		}
		return array;
	}

}
