package problem;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Crossover {
	public final int UC = 0;
	public final int OPC = 1;
	public final int TPC = 2;
	/**
	 * selects crossover based off of meme value. options are uniform crossover, one point and two-point
	 * @param parents - two parent solutions
	 * @return two child solutions created using uniform crossover
	 */
	public int[][] performCrossover(int[][] parents, int meme) {
		int[][] children = null ;
		switch(meme) {
		case UC:
			children = uniformCrossover(parents);
			break;
		case OPC:
			children = onePointCrossover(parents);
			break;
		case TPC:
			children = twoPointCrossover(parents);
			break;
		}

		return children;
	}

	/**
	 Takes one point and splits solutions, then other half of the solution is
	 swapped with the other child
	 * @param parents - parent solutions used for crossover
	 * @return child solutions produced by crossover
	 */
	public int[][] uniformCrossover(int[][] parents){
		int[][] children = new int[2][parents[0].length];
		for(int j = 0; j < 2; j++) {
			for(int i = 0; i < parents[0].length; i++) {
				if(Math.random() < 0.5) {
					children[j][i] = parents[0][i];
				}else {
					children[j][i] = parents[1][i];
				}
			}
		}

		return children;
	}

	/**
	Takes one point and splits solutions, then other half of the solution is
	 swapped with the other child
	 * @param parents - parent solutions used for crossover
	 * @return child solutions produced by crossover
	 */
	public int[][] onePointCrossover(int[][] parents){
		int[][] children = new int[2][parents[0].length];

		int point = (int) (Math.random()*(parents[0].length-1));

			children[0] = parents[0];
			children[1] = parents[1];
		
		for(int i = point; i < parents[0].length; i++) {
			children[0][i] = parents[1][i];
			children[1][i] = parents[0][i];
		}

		return children;
	}

	/**
	 * Takes two points and crosses over solutions 
	 * @param parents - parent solutions used for crossover
	 * @return child solutions produced by crossover
	 */
	public int[][] twoPointCrossover(int[][] parents){
		int[][] children = new int[2][parents[0].length];

		int[] points = IntStream.range(0, parents[0].length-1).toArray();

		points = shuffleArray(points);
		int[] index = {points[0], points[1]};
		Arrays.sort(index);

		children[0] = parents[0];
		children[1] = parents[1];

		for(int i = index[0]; i < index[1]; i++) {
			children[0][i] = parents[1][i];
			children[1][i] = parents[0][i];
		}

		return children;
	}

	/**
	 * Shuffles array by swapping each element with a random separate element in the array
	 * @param array
	 * @return the shuffled version of the array
	 */
	public static int[] shuffleArray(int[] array) {
		for(int i = 0; i < array.length; i++) {
			int r = (int) (Math.random()*array.length);
			int temp = array[i];
			array[i] = array[r];
			array[r] = temp;
		}
		return array;
	}
}
