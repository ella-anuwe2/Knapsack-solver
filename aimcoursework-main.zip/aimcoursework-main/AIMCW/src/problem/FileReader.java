package problem;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner; 

/**
 * reads the problem instance from a file and organises key information.
 * Contains an arraylist of items with their weights and profit.
 * contains the length of the solution/items list and their weights
 * @author ella_
 *
 */
public class FileReader {

	private ArrayList<double[]> items = new ArrayList<double[]>(); 
	private double weight;
	private int length;
	private String test;

	/** 
	 * constructor that initialises value for the test instance name
	 * @param stest
	 */
	public FileReader(String stest) {
		this.test = stest;
	}

	/**
	 * reads the file and enters information into the correct variables
	 * @return an arraylist of items and their profits and weights 
	 */
	public ArrayList<double[]> readFile(){

		try {
			File testFile = new File(test);
			Scanner myReader = new Scanner(testFile);

			String data = myReader.nextLine();
			String temp[] = data.split(" ");

			length = Integer.parseInt(temp[0]); 
			weight = Double.parseDouble(temp[1]);

			for (int i = 0; i < length; i++) {
				data = myReader.nextLine();
				temp = data.split(" ");

				double[] inttemp = new double[] {
						Double.parseDouble(temp[0]),
						Double.parseDouble(temp[1]),
				};
				items.add(inttemp);
				//				System.out.println(items.get(i)[0] + " " + items.get(i)[1]);
			}
			myReader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

		return items;
	}
	
	public void writeFile(String test2, int trialNumber, int numberOf, double bestFitness, double worstFitness) throws IOException {
		String name = test.replace(".txt", ("_trial" + trialNumber + ".txt"));
		File file = new File(name);
		FileWriter fw = new FileWriter(file);
		PrintWriter pw = new PrintWriter(fw);
		
		for(int i = 0; i < numberOf; i++) {
			pw.println("Best-" + i + " " + bestFitness);
			pw.println("Current-" + i + " " + worstFitness);
		}
		
		pw.close();
		
		
	}

	/**
	 * @return maximum weight for this problem instance
	 */
	public double getWeight() {
		return weight;
	}

	/**
	 * @return length of the solution without memetic part
	 */
	public int getLength() {
		return length;
	}
}
