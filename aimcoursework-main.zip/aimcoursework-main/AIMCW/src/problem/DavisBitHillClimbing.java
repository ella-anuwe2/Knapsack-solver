package problem;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.stream.IntStream;

/**
 * Davis bit hill climbing algorithm for both accepting worseing solutions and not accepting worsening solutions
 */
public class DavisBitHillClimbing extends HillClimbingAlgorithm{


	private FitnessEvaluator evaluator;
	private ArrayList<double[]> population;
	private boolean worsening;
	//	private FitnessEvaluator evaluator = new FitnessEvaluator(problem, items, populationSize);


	/**
	 * constructor for davis bit hill climbing class
	 * @param problem - contains data about the current knapsack problem instance
	 * @param populationSize - number of solutions in the population
	 * @param evaluator - instance of the FitnessEvaluator object used for this problem instance
	 * @param worsening - determines if worsening dolutions will be allowed or not
	 */
	public DavisBitHillClimbing(FileReader problem, int populationSize, FitnessEvaluator evaluator, boolean worsening) {
		this.problem = problem;
		this.populationSize = populationSize;
		this.evaluator = evaluator;
		this.worsening = worsening;
	}

	/**
	 * Performs Davis Bit hill climbing without accepting worsening solutions
	 * @param solution the solution that the local search is to be performed on
	 * @return the best solution found in the neighbourhood 
	 */
	public int[] applyHeuristic(int[] solution, int memeType, int memeLoop,  double fitness){
		if(memeType == 0) {
			solution = acceptWorsening(solution, memeLoop, fitness);
		}else {
			solution = improvingOnly(solution, memeLoop, fitness);
		}
		
		return solution;

	}

	/**
	 * 
	 * @param solution
	 * @param memeLoop
	 * @param fitness
	 * @return
	 */
	private int[] acceptWorsening(int[] solution, int memeLoop, double fitness) {
	
		for(int i = 0; i < memeLoop; i++) {
			double bestFitness = fitness;
			double weight = evaluator.evaluateSingleWeight(solution);
			int[] permutation = createPermutation(solution.length);
			for(int j = 0; j < solution.length; j++) {
				solution = bitFlip(solution, permutation[i]);
				double tempEval = evaluator.deltaEvaluation(solution, bestFitness, weight, permutation[i]);
				if(tempEval > bestFitness) {
					bestFitness = tempEval;
				}else {
					double p = 0.6;
					solution = Math.random() < p ? solution : bitFlip(solution, permutation[i]);
					
				}
			}
		}
		return solution;
	}

	/**
	 * 
	 * @param solution
	 * @param meme
	 * @param fitness
	 * @return
	 */
	private int[] improvingOnly(int[] solution, int memeLoop, double fitness) {
		for(int i = 0; i < memeLoop; i++) {
			boolean improved = false;
			double bestFitness = fitness;
			double weight = evaluator.evaluateSingleWeight(solution);
			int[] permutation = createPermutation(solution.length);
			for(int j = 0; j < solution.length; j++) {
				solution = bitFlip(solution, permutation[i]);
				double tempEval = evaluator.deltaEvaluation(solution, bestFitness, weight, permutation[i]);
				if(tempEval > bestFitness) {
					improved = true;
					bestFitness = tempEval;
				}else {
					solution = bitFlip(solution, permutation[i]);
				}
			}
			if(improved == false) {
				break;
			}
		}
		return solution;
	}

	/**
	 * Creates a stream of integers representing solution indexes, and then 
	 * puts them in a random order
	 * @param length - length of the permutation/exclusive upper limit for the array of indexes
	 * @return randomly ordered integers representing indexes in the solution
	 */
	public int[] createPermutation(int length) {
		int[] permutation = IntStream.range(0, length).toArray();
		shuffleArray(permutation);
		return permutation;
	}

}
