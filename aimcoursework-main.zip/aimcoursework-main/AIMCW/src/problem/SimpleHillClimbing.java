package problem;

import java.util.ArrayList;
/**
 * Simple hill climbing, with both best improvement and first improvement heuristic
 */
public class SimpleHillClimbing extends HillClimbingAlgorithm{

	private FitnessEvaluator evaluator;
	private int type;
	private FileReader problem;
	private ArrayList<double[]> items;


	/**
	 * Constructor for simple hill climbing object
	 * @param type - type of simple hill climbing heuristic 
	 * @param problem - the problem being solved
	 * @param items - arraylist of the knapsack items
	 * @param evaluator - the evaluator shared by the problem instance
	 */
	public SimpleHillClimbing(int type, FileReader problem, ArrayList<double[]> items, FitnessEvaluator evaluator) {
		this.type = type;
		this.problem = problem;
		this.items = items;
		this.evaluator = evaluator;
	}

	/**
	 * Applies huristic depending on the specified type of heuristic specified in the meme
	 * returns the solution after hill climbing
	 */
	public int[] applyHeuristic(int[] solution, int[] memeplex, double fitness) {
		if(type == 2 ) {
			solution = bestImprovement(solution, memeplex, fitness);
		}else {
			solution = firstImprovement(solution, memeplex, fitness);
		}
		return solution;
	}

	/**
	 * Best improving solution after checking the improvement of each bit flip
	 * @param solution
	 * @return solution after hill climbing improvement
	 */
	public int[] bestImprovement(int[] solution, int[] memeplex, double fitness) {
	
		for(int i = 0; i < memeplex[LOOP]; i++) {
			double bestEval = evaluator.evaluateSingleFitness(solution);
			boolean improved = false;
			int bestIndex = -1; 
			

			for(int j = 0; j < solution.length; j++) {
				solution = bitFlip(solution, j);
				double weight = evaluator.evaluateSingleWeightDelta(solution, i, bestIndex);
				double tempVal = evaluator.deltaEvaluation(solution, bestEval, weight, i);
				if(tempVal > bestEval) {
					bestIndex = j;
					bestEval = tempVal;
					improved = true;
				}
				solution = bitFlip(solution, j);
			}
			if(improved) {
				solution = bitFlip(solution, bestIndex);
				
			}
		}
		return solution;
	}

	/**
	 * First improving solution after checking the improvement of each bit flip
	 * @param solution
	 * @return solution after hill climbing improvement
	 */
	public int[] firstImprovement(int[] solution, int[] memeplex, double fitness) {
		double weight = evaluator.evaluateSingleWeight(solution);
		double bestEval = fitness; 
		for(int j = 0; j < memeplex[LOOP]; j++) {
			for(int i = 0; i < solution.length; i++) {
				solution = bitFlip(solution, i);
				double tempVal = evaluator.deltaEvaluation(solution, bestEval, weight, i);
				if(tempVal > bestEval) {
					break;
				}else {
					solution = bitFlip(solution, i);
				}
					
			}
			
		}

		return solution;
	}	
}