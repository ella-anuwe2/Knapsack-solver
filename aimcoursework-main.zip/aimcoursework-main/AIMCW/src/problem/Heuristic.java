package problem;

import java.util.ArrayList;
import java.util.Arrays;

public class Heuristic {

	/**
	 * 
	 * @param solution
	 * @param items
	 * @param meme - number of items that will be destroyed
	 * @return
	 */
	public int[] destroyHeavist(int[] solution, ArrayList<double[]> items, int meme) {
		int l = solution.length;
		double[][] sortedItems = new double[l][2];


		for(int i = 0; i < l; i++) {
			sortedItems[i][0] = items.get(i)[1];
			sortedItems[i][1] =  i;
		}

		Arrays.sort(sortedItems, (a, b) -> Double.compare(b[0], a[0]));

		for(int i = 0; i < meme; i++) {
			for(int j = 0; j < solution.length; j++) {
				if(solution[(int)(sortedItems[j][1])] == 1) {
					solution[(int)(sortedItems[j][1])] = 0;
					break;
				}
			}	
		}

		return solution;
	}

	
	
	/**
	 * applies ruin recreate heuristic
	 * @param solution
	 * @param items
	 * @param memeHeuristic
	 * @param memeIterations
	 * @return a solution closer to the weight limit
	 */
	public int[] applyHeuristic(int[] solution, ArrayList<double[]> items,  int memeHeuristic, int memeIterations) {
		if(memeIterations == 0) {
			solution = destroyHeavist(solution, items, memeIterations);
		}else {
			solution = addRemove(solution, items, memeIterations);
		}
		
		return solution;
	}

/**
 * removes heavy items, adds lightest
 * @param solution
 * @param items
 * @param meme number of iterations
 * @return a solution closer to the upper limit
 */
	private int[] addRemove(int[] solution, ArrayList<double[]> items, int meme) {
		solution = destroyHeavist(solution, items, meme);
		int l = solution.length;
		double[][] sortedItems = new double[l][2];


		for(int i = 0; i < l; i++) {
			sortedItems[i][0] = items.get(i)[1];
			sortedItems[i][1] =  i;
		}

		Arrays.sort(sortedItems, (a, b) -> Double.compare(a[0], b[0]));
		
		
			for(int j = 0; j < solution.length; j++) {
				if(solution[(int)(sortedItems[j][1])] == 0) {
					solution[(int)(sortedItems[j][1])] = 1;
					break;
				}
			}	
		
		return solution;
	}
	
	
	

}
