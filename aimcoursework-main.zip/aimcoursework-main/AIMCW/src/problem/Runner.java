package problem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.Random;
import java.util.stream.IntStream;



/**
 * main method where the multi memetic algorithm is implemented
 * it runs a certain number of trials, trial produces a solution that
 * is as close to the optimum as possible without exceeding the maximum weight
 *
 */
public class Runner {

	//change to double
	//disallow getting past the 
	private static String test = "hidden5_23_10000.txt";
	public final static FileReader problem = new FileReader(test);
	private static int populationSize = 40; //must be an even number
	private static int tournamentSize = populationSize;
	private static ArrayList<double[]> items = problem.readFile();
	private static FitnessEvaluator evaluator = new FitnessEvaluator(problem, items, populationSize);
	private static int numOfTrials = 5;
	private static double[] fitnessScores;
	private static Crossover crossover = new Crossover();
	private static double p = 0.7;

	//memetic parts 
	private static Meme memetic = new Meme(evaluator);
	private static ArrayList<int[]> memeplexList = new ArrayList<int[]>();
	private static ArrayList<int[]> childMemeplexList = new ArrayList<int[]>();
	private static double innovationRate = 0.4 ;
	private static int seconds = 3;

	private static int numberOf = 100;

	//meme 1
	private static final int DBHCW = 0;
	private static final int DBHC = 1;
	private static final int FI = 2;
	private static final int BI = 3;

	//meme0 - mutation rate, meme1 - local search method, meme3 - local search method parameter, meme4

	/**
	 * main contains a loop that runs performTrial() for a set number of trials 
	 * @param args
	 */
	public static void main(String[] args) {

		for(int i = 1; i <= numOfTrials; i++) {
			performTrial(i);
		}
	}

	//maybe make it able to stop early when optimal solution has been found
	/**
	 * the perform trial method goes through all of the steps of a multi memetic algorithm. it 
	 * first initialises a population, creates a child population, creates a new population using that
	 * and repeats the process for a number of iterations.
	 * @param trialNumber - current trial number being performed
	 * @param childmemeplexes 
	 * @param innovationRate 
	 */
	public static void performTrial(int trialNumber) {
		//initialise population and memeplexes
		ArrayList<int[]> population = initialisePopulation();

		//replace generations with time in seconds
		long endTime = System.currentTimeMillis() + (seconds * 1000);
		while(System.currentTimeMillis() < endTime) {
			//evaluate fitness
			fitnessScores = evaluator.evaluateFitness(population);			

			ArrayList<int[]> childPopulation = new ArrayList<int[]>();

			for(int j = 0; j < populationSize/2; j++) {

				//select 2 parents
				int[][] parents = tournamentSelection(tournamentSize, population, fitnessScores);

				//make sure gobal memeplexList is being updated
				//crossover memeplexes

				int index = population.indexOf(parents[0]);
				int index2 = population.indexOf(parents[1]);
				//				do crossover
				int[][] childSolutions = crossover.performCrossover(parents, memeplexList.get(index)[3]);


				int[][] childMemeplexes = memetic.simpleInheritanceForMemeplex(parents, memeplexList.get(index), memeplexList.get(index2));

				//mutate memeplexes
				childMemeplexes = memetic.mutateMemeplexes(childMemeplexes, innovationRate);

				childMemeplexList.add(childMemeplexes[0]);
				childMemeplexList.add(childMemeplexes[1]);

				//mutate
				childSolutions = mutate(childSolutions, memeplexList.get(index), memeplexList.get(index2));

				//hill climbing
				int[][] memeplexes = {memeplexList.get(index), memeplexList.get(index2) };

				childSolutions = hillClimbing(childSolutions, memeplexes);

//				for(int i = 0; i < 2; i++) {
//					if(evaluator.evaluateSingleFitness( childSolutions[i]) * 1.5 > problem.getWeight() ){
//						Heuristic ruinRecreate = new Heuristic();
//						childSolutions[i] = ruinRecreate.applyHeuristic(childSolutions[i], items, memeplexList.get(index)[4], memeplexList.get(index)[5]);
//					}
//				}



				childPopulation.add(childSolutions[0]);
				childPopulation.add(childSolutions[1]);

			}

			population = selectNewPopulation(population, childPopulation);
			childMemeplexList.clear();
			
			//printing to file
			int[] bestSolution = findBestSolution(population);
			double bestFitness = evaluator.evaluateTrueSingleFitness(bestSolution);
			double worstFitness = evaluator.evaluateWorstFitness(population, fitnessScores);
			try {
				problem.writeFile(test, trialNumber, numberOf, bestFitness, worstFitness);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		int[] bestSolution = findBestSolution(population);
		double bestFitness = evaluator.evaluateTrueSingleFitness(bestSolution);
		
		System.out.println("Trial#" + trialNumber);
		System.out.println(bestFitness);
		System.out.println(Arrays.toString(bestSolution).replace(", ", "").replace("[", "").replace("]", ""));
		System.out.println();

	}


	/**
	 * method to select the hill climbing method for that solution using 
	 * the memes for that solution
	 * @param childSolutions
	 * @return
	 */
	private static int[][] hillClimbing(int[][] childSolutions, int[][] memeplexes) {
		//deals with first memeplex index
		//		System.out.println(Arrays.toString(memeplex1));
		int memeIndex = 0;

		for(int i = 0; i < 2; i++){	
			switch(memeplexes[i][2]) {
			case DBHCW:
				DavisBitHillClimbing dbhcw = new DavisBitHillClimbing(problem, populationSize, evaluator, true);
				childSolutions[i] = dbhcw.applyHeuristic(childSolutions[i], memeplexes[i][1], memeplexes[i][2], fitnessScores[i]);
				break;
			case DBHC:
				DavisBitHillClimbing dbhc = new DavisBitHillClimbing(problem, populationSize, evaluator, false);
				childSolutions[i] = dbhc.applyHeuristic(childSolutions[i], memeplexes[i][1], memeplexes[i][2], fitnessScores[i]);
				break;
			case BI:
				SimpleHillClimbing bihc = new SimpleHillClimbing(memeIndex, problem, items, evaluator);
				childSolutions[i] = bihc.applyHeuristic(childSolutions[i], memeplexes[i], fitnessScores[i]);
				break;
			case FI:
				SimpleHillClimbing fihc = new SimpleHillClimbing(memeIndex, problem, items, evaluator);
				childSolutions[i] = fihc.applyHeuristic(childSolutions[i], memeplexes[i], fitnessScores[i]);
				break;
			}
		}
		return childSolutions;
	}

	/**
	 * takes in two populations and returns a new population by taking the best solutions
	 * from each population
	 * @param parents - parent population used to create child population
	 * @param children - child population
	 * @return a new population with the best individuals from previous populations
	 */
	public static ArrayList<int[]> selectNewPopulation(ArrayList<int[]> parents, ArrayList<int[]> children){


		double[] parentFitness = evaluator.evaluateFitness(parents);
		double[] childFitness = evaluator.evaluateFitness(children);

		for(int i = 0; i < populationSize; i++) {
			int minIndex = 0;
			for(int j = 0; j < populationSize; j++) {	
				if(parentFitness[j] < childFitness[i]) {
					//if child is larger, swap it with the smallest parent
					//find smallest parent
					if(parentFitness[j] < parentFitness[minIndex]) {
						minIndex = j;
					}	
				}	
			}
			if(minIndex != -1) {
				parentFitness[minIndex] = childFitness[i];
				parents.set(minIndex, children.get(i));
				//also replaces memeplexes
				memeplexList.set(minIndex, childMemeplexList.get(i));
			}

		}
		return parents;

	}

	/**
	 * takes in two child solutions and a mutation and returns them with 
	 * some of the genes mutated
	 * @param children - two children to be mutated
	 * @param mutationRate - the probability of the gene mutating
	 * @return mutated child solutions
	 */
	public static int[][] mutate(int[][] children, int[] memeplex1, int[] memeplex2) {

		int meme = memeplex1[0];
		int meme2 = memeplex2[1];

		double mutationRate = meme/children[0].length;
		double mutationRate2 = meme2/children[1].length;

		for(int i = 0; i < problem.getLength(); i++) {
			//check this inequality
			if(Math.random() < mutationRate) {
				children[0][i] = 1 - children[0][i];			
			}
			if(Math.random() < mutationRate2) {
				children[1][i] = 1 - children[1][i];
			}

		}
		return children;
	}




	//add more crossover methods with parameter settings

	/**
	 * selects the two best parents from a random segment of the overall population
	 * @param tournamentSize - number of solutions out of the one
	 * @param population - all individuals/ current solutions
	 * @param fitnesses - the fitnesses of all of the solutions in the population
	 * @return the two parents from the overall population
	 */
	public static int[][] tournamentSelection(int tournamentSize, ArrayList<int[]> population, double[] fitnesses) {
		int[][] parents = new int[2][];


		//selecting a random tournament population from the general population
		LinkedList<Integer> tournamentPop = new LinkedList<Integer>();
		for(int i = 0; i < populationSize; i++) {
			tournamentPop.add(i);
		}


		Collections.shuffle(tournamentPop);

		double max = Integer.MIN_VALUE;
		int posBest = -1;
		for(int i = 0; i < tournamentSize; i++) {
			if(fitnesses[tournamentPop.get(i)] > max) {
				max = fitnesses[tournamentPop.get(i)]; //max fitness
				posBest = i;
			}
		}

		parents[0] = population.get(posBest);
		tournamentPop.remove(posBest);
		tournamentSize--;

		posBest = -1;
		max = Integer.MIN_VALUE;
		for(int i = 0; i < tournamentSize; i++) {
			if(fitnesses[tournamentPop.get(i)] > max) {
				max = fitnesses[tournamentPop.get(i)];
				posBest = i;
			}
		}

		parents[1] = population.get(posBest);
		return parents;

	}

	/**
	 * initialises population using greedy heuristic which means the most 
	 * valuable items are more likely to me taken. they are not always taken 
	 * in order to make the inital population more diverse.
	 * @return starting population
	 */
	public static ArrayList<int[]> initialisePopulation(){
		ArrayList<int[]> population = new ArrayList<int[]>();

		population = ghMostProfitableItems(population, p);

		ArrayList<int[]> population2 = new ArrayList<int[]>();

		population2 = ghLowestWeightItems(population2, p);

		population = selectNewPopulation(population, population2);

		childMemeplexList.clear();

		return population;


	}

	/**
	 * Takes the items with the lowest weights
	 * @param population - population to add solutions to
	 * @return population - population of solutions using this heuristic
	 */
	private static ArrayList<int[]> ghLowestWeightItems(ArrayList<int[]> population, double p) {
		int l = problem.getLength();
		double[][] sortedItems = new double[l][2];

		for(int i = 0; i < l; i++) {
			sortedItems[i][0] = items.get(i)[0];
			sortedItems[i][1] =  i;
		}

		Arrays.sort(sortedItems, (a, b) -> Double.compare(a[1], b[1]));

		for(int i = 0; i < populationSize; i++) {

			int[] solutionTemp = new int[l];

			for(int j = 0; j < l; j++) {
				solutionTemp[j] = 0;
			}

			for(int j = 0; j < l; j++) {
				if(evaluator.evaluateSingleWeight(solutionTemp) < problem.getWeight()) {

					
					int t = Math.random() < p ? 1 : 0;
					solutionTemp[ (int) sortedItems[j][1]] = t;
				}

			}

			population.add(solutionTemp);
			childMemeplexList = memetic.initialiseMemeplex(childMemeplexList);
		}
		return population;
	}

	/**
	 * Heuristic that takes the most profitable itmes
	 * @param population - population to add solutions to
	 * @return population - population of solutions using this heuristic
	 */
	private static ArrayList<int[]> ghMostProfitableItems(ArrayList<int[]> population, double p) {
		int l = problem.getLength();
		double[][] sortedItems = new double[l][2];

		for(int i = 0; i < l; i++) {
			sortedItems[i][0] = items.get(i)[0];
			sortedItems[i][1] =  i;
		}

		Arrays.sort(sortedItems, (a, b) -> Double.compare(b[0], a[0]));

		//most profitable greedy heuristic  
		for(int i = 0; i < populationSize; i++) {

			int[] solutionTemp = new int[l];

			for(int j = 0; j < l; j++) {
				solutionTemp[j] = 0;
			}

			for(int j = 0; j < l; j++) {
				if(evaluator.evaluateSingleWeight(solutionTemp) < problem.getWeight()) {

					int t = Math.random() < p ? 1 : 0;
					solutionTemp[ (int) sortedItems[j][1]] = t;
				}

			}
			population.add(solutionTemp);
			memeplexList = memetic.initialiseMemeplex(memeplexList);
		}
		return population;
	}


	/**
	 * finds the fittest individual from an entire population, but without a penalty. 
	 * it instead evaluates them by considering solutions that go over the maximum weight
	 * as 0 profit
	 * @param population
	 * @return the best solution in the population
	 */
	private static int[] findBestSolution(ArrayList<int[]> population) {
		double[] fitnesses = evaluator.evaluateTrueFitness(population);
		double bestFitness = -1;
		int bestIndex = -1;
		for(int i = 0; i < fitnesses.length; i++) {
			if(fitnesses[i] > bestFitness) {
				bestFitness = fitnesses[i];
				bestIndex = i;
			}
		}

		return population.get(bestIndex);

	}

}
