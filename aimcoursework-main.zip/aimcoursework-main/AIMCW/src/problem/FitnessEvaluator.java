package problem;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * class used to evaluate the fitness of solutions/populations
 */
public class FitnessEvaluator {
	private int populationSize;
	private FileReader problem;
	private ArrayList<double[]> items;
	private double averageProfit;
	private double penalty;

	/**
	 * constructor that takes in the problem instance, 
	 * an arraylist of items and their weights and the 
	 * population size
	 */
	public FitnessEvaluator(FileReader problem, ArrayList<double[]> items, int populationSize) {
		this.problem = problem;
		this.items = items;
		this.populationSize = populationSize;
		averageProfit = totalProfit()/problem.getLength();

		this.penalty = calculatePenalty();
	}

	/**
	 * @return the penalty that will be taken from the solution's score if it goes over the limit
	 */
	private double calculatePenalty() {
		return  averageProfit*1.5; 
	}

	/**
	 * the overall profit if all of the items are taken
	 * @return total profit from all items
	 */
	public double totalProfit() {
		double total = 0;
		for(int i = 0; i < problem.getLength(); i++) {
			total += items.get(i)[0];
		}
		return total;
	}

	/**
	 * evaluates the fitnesses for an entire population of solutions
	 * @param population = all of the solutions
	 * @return a double array with the fitnesses of the population
	 */
	public double[] evaluateFitness(ArrayList<int[]> population) {
		double[] fitnessScores = new double[populationSize];
		//needs to loop through the number of individuals in the population
		for(int i = 0; i < populationSize; i++) {
			double profit = 0;
			double weight = 0;

			for(int j = 0; j < problem.getLength(); j++) {
				if(population.get(i)[j] == 1) {
					profit += items.get(j)[0];
					weight += items.get(j)[1];

				}
				if(weight > problem.getWeight()) {
					profit -= penalty;
				}
			}
			fitnessScores[i] = profit;
		}
		return fitnessScores;
	}

	/**
	 * evaluates the fitnesses without the penalty system. 0 score if the
	 * weight is over the limit
	 * @param population
	 * @return double array of true fitness scores
	 */
	public double[] evaluateTrueFitness(ArrayList<int[]> population) {
		double[] fitnessScores = new double[populationSize];
		//needs to loop through the number of individuals in the population
		for(int i = 0; i < populationSize; i++) {
			double profit = 0;
			double weight = 0;

			for(int j = 0; j < problem.getLength(); j++) {
				if(population.get(i)[j] == 1) {
					profit += items.get(j)[0];
					weight += items.get(j)[1];

				}
			}
			if(weight > problem.getWeight()) {
				profit = 0;
			}
			//			if(profit == 9767)
			//				System.out.println("found");
			fitnessScores[i] = profit;
		}
		return fitnessScores;
	}

	/**
	 * 
	 * @param solution
	 * @return the fitness of a single solution
	 */
	public double evaluateSingleFitness(int[] solution) {

		double profit = 0;
		double weight = 0;

		for(int i = 0; i < problem.getLength(); i++) {
			if(solution[i] == 1) {
				profit += items.get(i)[0];
				weight += items.get(i)[1];
				if(weight > problem.getWeight()) {
					profit -= penalty;
				}
			}
		}
		//		if(profit == 9767)
		//			System.out.println("found");
		return profit;
	}

	/**
	 * evaluates fitness for one solution with the profit going to
	 *  0 of the weight is over rather than using the penalty system
	 * @param solution
	 * @return single fitness score
	 */
	public double evaluateTrueSingleFitness(int[] solution) {
		double profit = 0;
		double weight = 0;

		for(int i = 0; i < problem.getLength(); i++) {
			if(solution[i] == 1) {
				profit += items.get(i)[0];
				weight += items.get(i)[1];
			}
		}
		if(weight > problem.getWeight()) {
			profit = 0;
		}

		return profit;
	}

	/**
	 * evaluates weight of a single solution
	 * @param solution 
	 * @return weight of a solution/individual
	 */
	public double evaluateSingleWeight(int[] solution) {

		double weight = 0;

		for(int i = 0; i < problem.getLength(); i++) {
			if(solution[i] == 1) {
				weight += items.get(i)[1];
			}
		}
		return weight;
	}

	/**
	 * calculates weights of an entire population
	 * @param population
	 * @return array with weight of population
	 */
	public double[] evaluateWeights(ArrayList<int[]> population) {
		double[] weights = new double[populationSize];
		//needs to loop through the number of individuals in the population
		for(int i = 0; i < populationSize; i++) {
			double weight = 0;

			for(int j = 0; j < problem.getLength(); j++) {
				if(population.get(i)[j] == 1) {
					weight += items.get(j)[1];
				}
			}
			weights[i] = weight;

		}
		return weights;
	}

	/**
	 * faster way of evaluating a solution
	 * @param solution - the solution
	 * @param fitness - the current fitness of the solution
	 * @param weight - current weight of the solution
	 * @param i - index of the bit that has changed
	 * @return fitness score for the solution
	 */
	public double deltaEvaluation(int[] solution, double fitness, double weight, int i) {
		if(solution[i] == 1) {
			fitness += items.get(i)[0];
			weight += items.get(i)[1];
			if(weight > problem.getWeight()) {
				fitness -= penalty;
			}
		}else {
			fitness -= items.get(i)[0];
			weight -= items.get(i)[1];
			if(weight < problem.getWeight() && (weight + items.get(i)[1]) > problem.getWeight()) {
				fitness += penalty;
			}

		}

		return fitness;
	}

	/**
	 * evaluates the weight of the solution without checking the entire thing
	 * @param solution
	 * @param weight - weight of solution before bit flipped
	 * @param i - index of the allel that was changed
	 * @return weight of the solution
	 */
	public double evaluateSingleWeightDelta(int[] solution, double weight, int i) {
		if(solution[i] == 1) {
			weight += items.get(i)[1];	
		}else {
			weight -= items.get(i)[1];
		}

		return weight;
	}

	/**
	 * 
	 * @param population - current solutions
	 * @param fitnessScores - all fitness scores for the population
	 * @return worst fitness in the population
	 */
	public double evaluateWorstFitness(ArrayList<int[]> population, double[] fitnessScores) {
		double worstFitness = Double.MAX_VALUE;
		return worstFitness;
	}


}
