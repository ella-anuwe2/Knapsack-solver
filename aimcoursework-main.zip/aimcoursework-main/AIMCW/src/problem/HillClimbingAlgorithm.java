package problem;

import java.util.ArrayList;

/**
 * Parent class for hill climbing algorithms
 *
 */
public class HillClimbingAlgorithm {

	protected int populationSize;
	protected FileReader problem;
	protected ArrayList<int[]> items;
	public final int LOOP = 2;

	/**
	 * constructor which takes in the knapsack problem data, a the list of items in the problem and the 
	 * population size
	 * @param problem
	 * @param items
	 * @param populationSize
	 */
	public HillClimbingAlgorithm(FileReader problem, ArrayList<int[]> items, int populationSize){
		this.problem = problem;
		this.items = items;
		this.populationSize = populationSize;
	}

	/**
	 * default constructor with no parameters
	 */
	public HillClimbingAlgorithm() {

	}


	/**
	 * Flips the bit at a specified index in the solution
	 * @param solution - the solution that the bit flipping is being performed on
	 * @param index - the position of the bit to be flipped
	 * @return the solution with 1 bit flipped
	 */
	public int[] bitFlip(int[] solution, int index) {
		solution[index] = 1 - solution[index];
		return solution;
	}

	/**
	 * Shuffles array by swapping each element with a random separate element in the array
	 * @param array
	 * @return the shuffled version of the array
	 */
	public static int[] shuffleArray(int[] array) {
		for(int i = 0; i < array.length; i++) {
			int r = (int) (Math.random()*array.length);
			int temp = array[i];
			array[r] = array[i];
			array[i] = temp;
		}
		return array;
	}

	/**
	 * @return the population size for this problem instance
	 */
	public int getPopulationSize() {
		return populationSize;
	}

	/**
	 * @return the data for the knapsack problem instance being solved
	 */
	public FileReader getProblem() {
		return problem;
	}

	/**
	 * @return arraylist of the items that can be taken or not taken
	 */
	public ArrayList<int[]> getItems() {
		return items;
	}

}
